var searchData=
[
  ['is_5fempty_38',['is_empty',['../list_8h.html#a4df754b95439918e8813c67771283a40',1,'list.c']]]
];
