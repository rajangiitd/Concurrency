var indexSectionsWithContent =
{
  0: "ahilmr",
  1: "hl",
  2: "hlm",
  3: "ahilmr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

